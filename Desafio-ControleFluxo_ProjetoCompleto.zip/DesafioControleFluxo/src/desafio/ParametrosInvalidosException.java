package desafio;

public class ParametrosInvalidosException extends Exception {
}
